# Unico Family Medicine — Home Care Module
## Product, Architecture & UI Design Plan

> **What this file is:** the single source of truth for building the Home Care Module (web admin + mobile app) **and** a ready-to-paste design brief for Claude Design. Engineering builds from §3–§12; design generates UI from §13–§15.

| Field | Value |
|---|---|
| Product | Unico Family Medicine — Home Care Module (internal hospital staff system) |
| Organisation | Unico Hospitals PLC, Dhaka · Family Medicine Department |
| Platforms | Web Admin (Next.js pages inside the existing Unico Vercel app) · Mobile App "Unico HomeCare" (Android + iOS) |
| Core stack | Next.js 15 App Router (TypeScript) · MongoDB Atlas · Upstash Redis cache · Expo (React Native) |
| Messaging | In-app · Push (Expo → FCM/APNs) · Email (Gmail) · WhatsApp (deep link in v1 → Cloud API in v3) |
| Access model | Admin roles = Web + App · Field staff = App only |
| Version | v1.0 · 24 September 2026 |

**Reading guide**

| Audience | Sections |
|---|---|
| Product / management | §1 Vision · §2 Scope · §16 Roadmap · §17 Open questions |
| Engineering | §3 Roles · §4 Lifecycle · §5 Features · §6 Architecture · §7 Data model · §8 Cache · §9 API · §10 Templates · §11 Security · §12 Deployment |
| Design (Claude Design) | §13 Design system · §14 Screen inventory · §15 Claude Design prompt |

---

## 1. Vision & Goals

**Vision.** One system where the Family Medicine department receives home-care requests, verifies and confirms them, assigns the right hospital staff, tracks every visit from acceptance to a timed completion tick, records every data point, and keeps patients and staff informed automatically through push, Gmail and WhatsApp.

| # | Goal | Success looks like |
|---|---|---|
| G1 | Zero lost requests | Every request has a status, an owner and a timestamp from the moment it is created |
| G2 | Right person, right time | Assignment suggestions use skill, availability, zone and workload; staff accept in-app |
| G3 | Proof of service | Check-in / check-out timestamps, ticked checklist with times, vitals, photos, signature, auto report |
| G4 | Automatic communication | Patient and staff informed at every state change (push, email, WhatsApp) without phone calls |
| G5 | Complete record | Every create / update / status change / message is written to an append-only audit log |
| G6 | Cheap and fast to run | Serverless on Vercel, cached reads via Redis, free or low tiers for Atlas, Upstash, Expo push |

**KPI targets (v1)**

| KPI | Target |
|---|---|
| Request → Confirmed | ≤ 15 min (Urgent ≤ 5 min) |
| Confirmed → Assigned | ≤ 30 min |
| Assigned → Accepted by staff | ≤ 15 min |
| On-time arrival (check-in within +10 min of schedule) | ≥ 90 % |
| Visit report submitted same day | 100 % |
| Patient notified at confirmation and assignment | 100 % |

---

## 2. Scope

| In scope (v1) | Out of scope (v1) | Planned later |
|---|---|---|
| Staff & designation management, RBAC, web/app access control | Patient-facing app / self-booking | Patient portal + online booking (Phase 5) |
| Home care request intake & full records | Billing / accounting ledger | HIS / MRN integration, invoicing |
| Patient board (registry + profile + history) | Ambulance dispatch | Driver module, live GPS tracking |
| Assignment (manual + ranked suggestions) with accept / decline | Auto-assignment | Auto-assign toggle (Phase 4) |
| Visit execution: check-in, checklist ticks with time, vitals, notes, photos, signature, check-out, completion | Tele-consultation / video | Video follow-up |
| Notifications: in-app, push, Gmail email, WhatsApp deep link | WhatsApp Cloud API automated sends | Cloud API + inbound replies (Phase 3) |
| Append-only audit log, message logs | SMS gateway | BD SMS aggregator (Phase 3) |
| Dashboard, reports, CSV / Excel export | Payroll / incentives | Staff incentive report |

---

## 3. Users, Roles, Designations & Platform Access

### 3.1 Actors

| Actor | Role code | Platform | Main jobs |
|---|---|---|---|
| System owner / IT | `SUPER_ADMIN` | Web + App | Users, designations, settings, integrations, audit |
| Home Care Coordinator (Family Medicine) | `HC_ADMIN` | Web + App | Verify, confirm, assign, monitor, close visits, reports |
| Front desk / call centre | `FRONT_DESK` | Web + App | Create requests, patient registry, send confirmations |
| Family Medicine doctor | `DOCTOR` | App | Accept visits, examination notes, prescription, completion |
| Nurse | `NURSE` | App | Accept visits, checklist, vitals, procedures, completion |
| Allied health (physio, lab / phlebotomy, attendant) | `ALLIED` | App | Accept visits, service checklist, completion |
| Driver / transport (optional) | `DRIVER` | App | Trip assignment, en-route / arrived |
| Management (read-only) | `VIEWER` | Web | Dashboards and reports |

### 3.2 Role vs designation (two separate things)

| Concept | Meaning | Managed by | Examples |
|---|---|---|---|
| **Role** | Permission set, fixed in code | Developers | `NURSE`, `HC_ADMIN` |
| **Designation** | HR title shown on profile, visit reports and patient messages | Admin → Settings → Designations | Senior Staff Nurse · Registrar – Family Medicine · Consultant – Family Medicine · Physiotherapist · Medical Technologist (Lab) |
| **Department** | Organisational unit | Admin | Family Medicine · Nursing · Laboratory · Physiotherapy · Transport · IT / Admin |
| **Skills** | Tags used by assignment suggestions | Admin / user | `iv_cannulation`, `wound_care`, `catheter_care`, `ecg`, `sample_collection`, `physio_neuro`, `paediatric` |
| **Zones** | Dhaka areas a staff member covers | Admin / user | Dhanmondi, Mohammadpur, Uttara, Mirpur, Gulshan, Banani, Motijheel, Savar |

**Add-user form (Settings → Staff → Add user):** Employee ID · Full name (EN / BN) · Phone (= WhatsApp number) · Email · Department · Designation · Role · Skills · Zones · Platform access (Web / App) · Shift (Morning / Evening / Night / Flexible) · Status (Active / Suspended) · Temporary password or invite link.

### 3.3 Permission matrix

| Capability | SUPER_ADMIN | HC_ADMIN | FRONT_DESK | Field (DOCTOR / NURSE / ALLIED / DRIVER) | VIEWER |
|---|:-:|:-:|:-:|:-:|:-:|
| Manage users, designations, departments | ✓ | – | – | – | – |
| Settings, integrations (Gmail, WhatsApp), templates | ✓ | templates only | – | – | – |
| Create request, edit patient registry | ✓ | ✓ | ✓ | – | – |
| Verify / confirm / reschedule / cancel | ✓ | ✓ | – | – | – |
| Assign / reassign staff | ✓ | ✓ | – | – | – |
| Accept / decline own assignment | – | – | – | ✓ | – |
| Check-in, checklist ticks, vitals, notes, check-out, complete (own visit) | – | – | – | ✓ | – |
| View all requests / patient board | ✓ | ✓ | ✓ | – | ✓ |
| View own visits only | – | – | – | ✓ | – |
| Send email / WhatsApp from a record | ✓ | ✓ | ✓ | assigned patient only | – |
| Close visit (verify report) | ✓ | ✓ | – | – | – |
| Reports & export | ✓ | ✓ | – | – | ✓ |
| Audit log | ✓ | read | – | – | – |

### 3.4 Platform access rule

- `user.platformAccess` is an array: `["web","app"]` for admin roles, `["app"]` for field roles (defaults by role, editable per user).
- Login receives `client: "web" | "app"`; if the client is not in `platformAccess`, login is refused: *"Your account is app-only. Please use the Unico HomeCare app."*
- JWT carries `aud` (`web` / `app`) and `role`; API middleware checks both on every request.
- A field user promoted to coordinator simply gets `web` added — no re-registration.

---

## 4. Home Care Lifecycle (core workflow)

### 4.1 State machine

```mermaid
stateDiagram-v2
    [*] --> NEW : request created
    NEW --> VERIFIED : identity, phone, address verified
    VERIFIED --> CONFIRMED : slot and fee agreed with patient
    CONFIRMED --> ASSIGNED : coordinator assigns staff
    ASSIGNED --> ACCEPTED : staff accepts
    ASSIGNED --> CONFIRMED : declined or 15 min timeout, reassign
    ACCEPTED --> EN_ROUTE : staff starts journey
    ACCEPTED --> IN_PROGRESS : check-in
    EN_ROUTE --> IN_PROGRESS : check-in at patient home
    IN_PROGRESS --> COMPLETED : mandatory ticks done, check-out, complete
    COMPLETED --> CLOSED : coordinator verifies report
    CONFIRMED --> RESCHEDULED : new slot
    ASSIGNED --> RESCHEDULED : new slot
    ACCEPTED --> RESCHEDULED : new slot
    RESCHEDULED --> CONFIRMED : re-confirmed
    NEW --> CANCELLED
    VERIFIED --> CANCELLED
    CONFIRMED --> CANCELLED
    ASSIGNED --> CANCELLED
    ACCEPTED --> CANCELLED
    CLOSED --> [*]
    CANCELLED --> [*]
```

### 4.2 Status reference

| Status | Set by | Trigger | Timestamp written | Auto-notify |
|---|---|---|---|---|
| `NEW` | Front desk / HC admin / web form | Request saved | `requestedAt` | HC_ADMIN (in-app + push) |
| `VERIFIED` | HC_ADMIN | Patient identity, phone, address checked | `verifiedAt` | — |
| `CONFIRMED` | HC_ADMIN | Slot + fee agreed | `confirmedAt` | Patient (WhatsApp / email), front desk |
| `ASSIGNED` | HC_ADMIN | Staff selected | `assignedAt` | Staff (push + in-app + WhatsApp), patient (staff name + time) |
| `ACCEPTED` | Staff | Taps **Accept** | `acceptedAt` | HC_ADMIN |
| back to `CONFIRMED` | Staff / timer | **Decline** with reason, or 15 min no response | `declinedAt` | HC_ADMIN escalation + next candidate suggested |
| `EN_ROUTE` | Staff | Taps **Start journey** | `enRouteAt` | Patient ("on the way") |
| `IN_PROGRESS` | Staff | **Check-in** (timestamp + optional GPS) | `checkInAt` | HC_ADMIN, patient ("arrived") |
| `COMPLETED` | Staff | Mandatory checklist ticked + **Check-out** + **Complete** | `checkOutAt`, `completedAt` | HC_ADMIN, patient (thank-you + feedback), department email with report |
| `CLOSED` | HC_ADMIN | Report verified, payment reconciled | `closedAt` | — |
| `RESCHEDULED` | HC_ADMIN | New slot chosen | `rescheduledAt` | Staff, patient |
| `CANCELLED` | HC_ADMIN | Reason captured | `cancelledAt` | Staff, patient |

### 4.3 Timing metrics (computed, shown on visit timeline and reports)

| Metric | Formula | Target |
|---|---|---|
| Response time | `confirmedAt − requestedAt` | ≤ 15 min (Urgent ≤ 5) |
| Assignment time | `assignedAt − confirmedAt` | ≤ 30 min |
| Acceptance time | `acceptedAt − assignedAt` | ≤ 15 min |
| Punctuality | `checkInAt − scheduledAt` | ≤ +10 min (late flag beyond) |
| Visit duration | `checkOutAt − checkInAt` | Service default ± 25 % (overtime prompt beyond) |
| Turnaround | `completedAt − requestedAt` | Routine ≤ 48 h · Urgent same day · Emergency ≤ 2 h |
| Report lag | `closedAt − completedAt` | Same day |

Every timestamp stores `serverAt` (authoritative) and, for mobile actions, `deviceAt` + `offline: true/false` so offline ticks keep their true time.

### 4.4 Priority & SLA

| Priority | Definition | Confirm within | Visit within |
|---|---|---|---|
| `ROUTINE` | Scheduled care (dressing, physio, sample collection) | 15 min | 24–48 h |
| `URGENT` | Same-day need (fever with comorbidity, blocked catheter) | 5 min | Same day |
| `EMERGENCY` | Life-threatening → advise ER / ambulance, log the call | Immediate | ≤ 2 h or redirect to ER |

---

## 5. Feature Modules (functional spec)

### 5.1 Authentication & access
- Login: employee ID **or** phone **or** email + password; optional OTP (SMS / email) for password reset.
- Web: JWT in httpOnly cookie (access 15 min, refresh 30 days, rotating). App: bearer access + refresh stored in secure storage; device registered (model, OS, push token).
- Middleware: `requireAuth(role[])` on every route handler; `aud` must match client; suspended users rejected instantly (Redis deny-list).
- Sessions page: user sees devices, can sign out others; admin can force sign-out.
- Rate limiting on login / OTP (Upstash Ratelimit).

### 5.2 System users & designations
- CRUD users with fields in §3.2; bulk import from CSV (employee ID, name, phone, designation).
- Designation and department lists (EN / BN titles, grade, active flag). Deleting a designation in use is blocked; deactivate instead.
- Availability toggle (**On duty / Off duty / On leave**) shown in assignment panel; optional weekly shift roster (Phase 4).
- Profile: photo, designation, skills, zones, stats (visits this month, on-time %, average rating).

### 5.3 Home care request intake & records
- **Create request** (web form or app quick form). Fields:

| Group | Fields |
|---|---|
| Patient | Existing patient search (phone / MRN / name) or new: name (EN / BN), age or DOB, gender, phone, alternate phone, MRN, blood group |
| Address | Area / thana, full address, landmark, optional GPS pin, map link |
| Requester | Self / relative: name, relationship, phone |
| Service | One or more service types (§5.12), priority, preferred date, preferred slot, expected duration |
| Clinical | Chief complaint, clinical notes, referring doctor, allergies, attachments (prescription / report photos) |
| Commercial | Estimated fee, payment method (Cash / bKash / Nagad / Card), payment status |
| Meta | Source (phone, walk-in, WhatsApp, website, app), created by, internal remarks |

- Request number auto-generated: `HC-YYMMDD-NNNN` (e.g. `HC-260924-0007`).
- Record view = tabs: **Overview · Timeline · Assignment · Visit data · Messages · Attachments · Audit**.
- Every field change is versioned (before / after) in `audit_logs`.
- Duplicate guard: same phone + service + date within 2 h → warning.

### 5.4 Patient board & registry
- **Patient board (web + app):** all patients with latest home-care status, next scheduled visit, assigned staff, priority chip, SLA countdown. Filters: status, service, zone, staff, date, priority. Quick actions: Call, WhatsApp, Open record, Assign.
- **Live requests board (web):** Kanban columns `NEW · CONFIRMED · ASSIGNED · IN PROGRESS · COMPLETED · CLOSED / CANCELLED`, drag to change status (permission-checked), SLA colour on cards.
- **Patient profile:** demographics, guardian, address history, allergies, all visits (timeline), documents, consent flag, notes, total visits, outstanding balance.
- Search by phone (fastest), MRN, name (EN / BN).

### 5.5 Assignment system (after CONFIRMED)
1. Coordinator opens **Assign** → candidate list ranked by score:

| Factor | Weight | Rule |
|---|---|---|
| Skill match | 40 | Service type required skills ⊆ user skills |
| Availability | 30 | On duty, no overlapping visit within (duration + 45 min travel) |
| Zone match | 20 | Patient area ∈ user zones |
| Workload | 10 | Fewer visits today ranks higher |

   Badges shown: `Skill ✓` · `Free 15:00–17:00` · `Zone ✓` · `2 visits today` · `On leave`.
2. Coordinator picks **primary** staff (+ optional secondary, e.g. nurse + attendant), sets scheduled date/time, expected duration, instructions, fee.
3. Staff gets push + in-app card + optional WhatsApp; must **Accept** or **Decline** (reason: unavailable / too far / skill / sick / other) within 15 min (configurable).
4. Timeout or decline → status back to `CONFIRMED`, coordinator gets escalation notification with the next best candidate pre-selected.
5. Reassign allowed until `IN_PROGRESS`; every change writes `assignment_logs {from, to, reason, by, at}`.
6. Route mode: coordinator can assign one staff several visits for a day; app orders them by time and shows a day route.
7. Phase 4: **Auto-assign** toggle for `ROUTINE` requests (top-ranked candidate assigned automatically, still requires acceptance).

### 5.6 Visit execution, completion tick & timing
- **Visit detail (app):** patient card (name, age / gender, phone → Call / WhatsApp; address → Map), service, scheduled time, instructions, attachments, live status stepper.
- Action bar, in strict order: **Start journey → Check-in → Checklist → Check-out → Complete**. Each button stamps `serverAt` + `deviceAt`.
- **Checklist:** template per service type; items mandatory / optional; a tick stores `{doneAt, by}` and shows the time inline; unticking requires a reason; ad-hoc items can be added.
- **Vitals:** BP, pulse, temperature, SpO₂, RBS, weight, pain score — validated ranges; abnormal values highlighted and flagged to coordinator.
- **Notes:** clinical notes (doctor), nursing notes, medication administered (drug, dose, route, time), consumables used (for billing).
- **Photos:** wound / dressing / sample label; compressed on device, time-watermarked, uploaded to blob storage.
- **Confirmation:** patient / relative signature pad **or** OTP to patient phone **or** "confirmed verbally" fallback (logged).
- **Timer widget:** elapsed time since check-in, scheduled vs actual, late flag (> +10 min), overtime prompt (> planned + 25 %).
- **Complete** is enabled only when all mandatory items are ticked and check-out is stamped → summary screen → submit → `COMPLETED` → report (HTML / PDF) auto-generated, stored, emailed to the department.
- **Offline:** assigned visits cached on device; ticks, vitals, notes queue locally and sync on reconnect. Conflict rule: server wins for status, device wins for tick timestamps.

### 5.7 Notification system
Channels: **In-app** (notification centre + badges) · **Push** (Expo → FCM / APNs) · **Email** (Gmail) · **WhatsApp** (deep link v1, Cloud API v3) · **SMS** (optional later).

| Event | Recipients | Channels |
|---|---|---|
| Request created | HC_ADMIN | in-app, push |
| Confirmed | Patient · front desk | WhatsApp / email · in-app |
| Assigned | Staff · patient · HC_ADMIN | push + in-app + WhatsApp · WhatsApp · in-app |
| Accepted / declined / timeout | HC_ADMIN | in-app, push (decline = high priority) |
| Reminder T-2 h and T-30 min | Staff · patient | push · WhatsApp |
| En route / check-in | Patient · HC_ADMIN | WhatsApp · in-app |
| Abnormal vitals flagged | HC_ADMIN, on-call doctor | push (high), in-app |
| Completed | HC_ADMIN · patient · department | in-app · WhatsApp (thank-you + feedback link) · email with report |
| Overdue (not checked-in 15 min after schedule) | Staff · HC_ADMIN | push · push + in-app |
| Rescheduled / cancelled | Staff · patient | push · WhatsApp |
| Daily digest 20:00 | HC_ADMIN, VIEWER | email |

- Per-user preferences (push for assignment cannot be disabled). Quiet hours 22:00–07:00 batch non-urgent notifications.
- Delivery pipeline: event → `notifications` document → fan-out per channel → provider call inside `after()` (Next.js) → retry up to 3× via QStash → per-channel status (`queued / sent / delivered / failed`).
- Notification centre: grouped Today / Earlier, tap → deep link to the visit, mark read / read all, unread badge on tab and bell.

### 5.8 Email system (Gmail)
| Option | How | When to use |
|---|---|---|
| **A. Gmail SMTP + App Password** (Nodemailer, `smtp.gmail.com:465`) | Enable 2-Step Verification on the sending account, create an App Password, put it in env vars | Fastest start; ≈ 500 mails / day (free Gmail) or ≈ 2 000 / day (Workspace) |
| **B. Gmail API + OAuth2 refresh token** (`googleapis`) | Google Cloud project → OAuth consent → refresh token in env | More reliable on serverless, same daily limits; recommended for a Workspace account like `homecare@unicohospitals.com` |

- Secrets live only in Vercel env vars; Settings UI holds non-secret config: from-name, reply-to, department CC list, template on/off switches, **Send test email**.
- Templates (HTML, Bangla-safe font stack): request confirmation (patient) · assignment notice (staff copy) · visit report (department + optional patient) · daily digest (admin) · escalation alert · password reset / OTP.
- Sending runs in `after()` so the API response is not blocked; failures go to the outbox and QStash retries; every send is written to `message_logs`.
- Attachments: visit report PDF; images linked, not attached (size).

### 5.9 WhatsApp system
**Tier 1 — Deep link (v1, no API approval needed).** "Send WhatsApp" on any record or visit → API renders the template with patient details → app opens `whatsapp://send?phone=8801XXXXXXXXX&text=<encoded>` (fallback `https://wa.me/8801XXXXXXXXX?text=<encoded>`) → user taps **Send** in WhatsApp → app records `SENT_CONFIRMED` (with an "I sent it" confirmation if the OS cannot report back). Works with normal WhatsApp and WhatsApp Business on the staff phone.

```mermaid
sequenceDiagram
    participant U as Staff / Coordinator (App or Web)
    participant API as Next.js API (Vercel)
    participant WA as WhatsApp app on device
    U->>API: POST /messages/whatsapp/prepare {requestId, template}
    API-->>U: {to, text, logId} rendered from template
    U->>WA: open whatsapp://send?phone=to&text=encoded
    WA-->>U: user taps Send
    U->>API: PATCH /messages/{logId} {status: SENT_CONFIRMED}
    API->>API: message_logs + audit_logs updated
```

**Tier 2 — WhatsApp Cloud API (Phase 3, fully automatic).** Meta Business verification for Unico Hospitals + a dedicated number → approved message templates (Bangla + English) → API sends on state change with no human tap → webhook stores delivery status and inbound replies (e.g. patient replies "CONFIRM" / "RESCHEDULE"). Same `message_logs` collection, `provider = cloud_api`.

Rules: send the minimum necessary patient data; never send diagnosis or lab values over WhatsApp; patient consent flag checked before any patient-facing message; every message (text, recipient, template, sender, time, status) logged.

### 5.10 Records & audit log ("every data recorded")
- `audit_logs` is **append-only** (no update / delete API): `actor, action, entity, entityId, before, after, ip, userAgent, client, serverAt`.
- Logged: logins / logouts / failed logins, user changes, request field edits, every status transition, assignment changes, checklist ticks / unticks, vitals, notes, uploads, messages sent (email / WhatsApp / push), settings changes, exports.
- Viewer UI (web): filter by entity, user, action, date; export CSV.
- Retention: visit and audit records ≥ 7 years (medical-record practice); soft-delete only, with `deletedAt`.

### 5.11 Dashboard & reports
- **Today tiles:** new, confirmed, assigned, in progress, completed, overdue, awaiting acceptance.
- **Charts:** requests per day (14 d), completion by service type, average response / assignment / visit duration, on-time %, top zones.
- **Staff report:** visits, on-time %, average duration, declines, ratings.
- **Exports:** CSV / Excel of requests, visits, messages, audit; monthly PDF summary.

### 5.12 Settings & master data
- Designations, departments, zones, shifts, slots (e.g. 09–11, 11–13, 15–17, 17–19), SLA thresholds, working hours.
- **Service types** with checklist templates, default duration, required skills, fee:

| Service | Mandatory checklist items (examples) | Default |
|---|---|---|
| Doctor home visit | History · examination · vitals · prescription · advice · follow-up plan | 45 min |
| Nursing care visit | Vitals · medication given · hygiene / care · patient education | 45 min |
| Injection / IV infusion | Verify prescription · patient ID check · administer · observe 15 min · document | 40 min |
| Wound dressing | Assess wound · clean · dress · photo · next dressing date | 30 min |
| Sample collection (lab) | Verify tests · collect · label · cold chain · hand over to lab · report ETA | 20 min |
| Physiotherapy session | Assessment · exercises · home programme | 45 min |
| Catheter / NG tube care | Check indication · procedure · document | 30 min |
| Post-operative care | Wound check · vitals · pain · medication · red-flag screen | 45 min |
| Elderly / palliative care | Vitals · comfort care · medication · family counselling | 60 min |
| Vaccination | Verify vaccine · cold chain · administer · observe · card update | 20 min |
| Health check package | BP · RBS · ECG · weight · report | 40 min |
| Oxygen / nebulisation | Set up · monitor SpO₂ · document | 30 min |

- Templates editor (EN / BN) for email and WhatsApp with placeholders `{patientName} {requestNo} {serviceType} {date} {slot} {staffName} {designation} {address} {patientPhone} {notes} {feedbackLink}`.
- Integrations: Gmail (mode A / B, test send), WhatsApp (deep link number, Cloud API token / phone ID / webhook secret), Push (Expo token check), feature toggles (auto-assign, GPS required at check-in, OTP confirmation).

---

## 6. System Architecture

### 6.1 Stack

| Layer | Choice | Why |
|---|---|---|
| Web admin + API | Next.js 15 App Router, TypeScript strict, Route Handlers under `/api/v1` | Lives inside the existing Unico Vercel app; one codebase serves web pages and the mobile API |
| Mobile app | Expo SDK 52+ (React Native), Expo Router, NativeWind, TanStack Query, Zustand, expo-notifications, expo-location, expo-image-picker, expo-linking, MMKV / SQLite for offline queue | Shares TypeScript types with the API; one build for Android + iOS; EAS Build produces APK / AAB / IPA. *Alternative:* Kotlin + Jetpack Compose if Android-only is acceptable |
| Database | MongoDB Atlas (M0 free → M10) via Mongoose or the native driver + Zod | Flexible visit documents, free tier to start |
| Cache | Upstash Redis (REST, serverless-friendly) | Dashboard counters, list pages, sessions, rate limits |
| Queue / schedule | Upstash QStash | Retries, reminders, escalations, daily digest — Vercel functions cannot run background workers |
| Push | Expo Push Service → FCM / APNs | Free, no native Firebase code needed |
| Email | Gmail (Nodemailer SMTP or Gmail API) | Required by the department |
| WhatsApp | Deep link (v1) → WhatsApp Cloud API (v3) | Zero setup now, full automation later |
| Files | Vercel Blob or Cloudflare R2 | Photos, signatures, report PDFs |
| UI kit (web) | Tailwind CSS + shadcn/ui (Radix), TanStack Table, React Hook Form + Zod, Recharts, Lucide icons | Same kit family already used on other projects |

### 6.2 Diagram

```mermaid
flowchart LR
    subgraph Clients
        M["Staff Mobile App (Expo / React Native)"]
        W["Admin Web (Next.js pages in the existing Unico Vercel app)"]
    end
    subgraph Vercel["Vercel · Next.js 15 App Router"]
        API["/api/v1 Route Handlers · REST + RBAC"]
        JOBS["Job handlers · reminders, outbox, escalations, digest"]
    end
    DB[("MongoDB Atlas")]
    RD[("Upstash Redis · cache, sessions, rate limit")]
    QS["Upstash QStash · queues and schedules"]
    PUSH["Expo Push Service -> FCM / APNs"]
    MAIL["Gmail SMTP / Gmail API"]
    WA["WhatsApp · wa.me deep link (v1) / Cloud API (v3)"]
    BLOB["Vercel Blob or Cloudflare R2 · photos, reports"]
    M --> API
    W --> API
    API --> DB
    API --> RD
    API --> QS
    QS --> JOBS
    JOBS --> DB
    API --> PUSH
    API --> MAIL
    M -. deep link .-> WA
    API -. Cloud API .-> WA
    API --> BLOB
```

### 6.3 Vercel constraints and how they are handled

| Constraint | Handling |
|---|---|
| Serverless timeouts (Hobby 10 s default, Pro up to 300 s) | Keep handlers under 5 s; send email / push / WhatsApp inside `after()`; heavy jobs via QStash |
| No background workers | QStash schedules: reminders every 5 min, escalations every 5 min, outbox retry every 2 min, digest daily 20:00 |
| Cold starts | Reuse Mongo client across invocations (global singleton); Redis via REST |
| Hobby plan forbids commercial use | Use **Vercel Pro** (or self-host the same Next.js app on a Coolify VPS if preferred) |
| No websockets | Web: TanStack Query polling 15–30 s on boards; app: push + pull-to-refresh; optional Pusher / Ably later |
| Function size | Do not bundle Puppeteer; generate report PDF with `@react-pdf/renderer` or `pdf-lib` |

### 6.4 Repository layout (suggested)

```
unico-app/                       # existing Next.js app on Vercel
├─ app/
│  ├─ (admin)/homecare/          # web admin pages (route group, protected)
│  │   ├─ dashboard/ requests/ patients/ staff/ reports/ messages/ settings/ audit/
│  └─ api/v1/                    # route handlers shared by web + mobile
│      ├─ auth/ users/ designations/ patients/ requests/ notifications/ messages/ reports/ settings/ jobs/
├─ lib/
│  ├─ db/          # mongo client, models, indexes
│  ├─ cache/       # upstash redis helpers, key builders, invalidation
│  ├─ auth/        # jwt, rbac middleware, platform check
│  ├─ notify/      # push.ts email.ts whatsapp.ts fanout.ts
│  ├─ services/    # request.service assignment.service visit.service audit.service
│  └─ templates/   # email + whatsapp templates (en, bn)
├─ shared/         # zod schemas + TS types published to the mobile app (npm workspace)
unico-homecare-mobile/           # Expo app
├─ app/            # expo-router: (auth)/ (tabs)/ visit/[id]/ admin/
├─ features/       # visits, auth, notifications, patients, assignment
├─ lib/            # api client, offline queue, push registration, whatsapp deep link
```

### 6.5 Real-time & offline strategy

| Need | Approach |
|---|---|
| Coordinator sees new requests / status changes | Web polling 15 s on boards + browser notification; app push |
| Staff sees new assignment instantly | Push notification with deep link; app refetches on foreground |
| Staff works in a home with weak signal | Visit detail + checklist cached; actions queued with `deviceAt`; sync banner shows pending count |
| Two coordinators edit the same request | Optimistic concurrency: `version` field; second write gets 409 and a reload prompt |

---

## 7. Data Model (MongoDB)

### 7.1 Entity relationships

```mermaid
erDiagram
    DEPARTMENTS ||--o{ DESIGNATIONS : groups
    DEPARTMENTS ||--o{ USERS : employs
    DESIGNATIONS ||--o{ USERS : titles
    PATIENTS ||--o{ HOMECARE_REQUESTS : requests
    SERVICE_TYPES ||--o{ HOMECARE_REQUESTS : classifies
    USERS ||--o{ HOMECARE_REQUESTS : assigned_primary
    HOMECARE_REQUESTS ||--o{ ASSIGNMENT_LOGS : reassign_history
    HOMECARE_REQUESTS ||--o{ MESSAGE_LOGS : sends
    HOMECARE_REQUESTS ||--o{ ATTACHMENTS : files
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ AUDIT_LOGS : performs
    USERS ||--o{ SESSIONS : holds
```

### 7.2 Collections

```ts
// users
{
  _id, employeeId, name: { en, bn }, phone, whatsapp, email, passwordHash,
  role: 'SUPER_ADMIN'|'HC_ADMIN'|'FRONT_DESK'|'DOCTOR'|'NURSE'|'ALLIED'|'DRIVER'|'VIEWER',
  departmentId, designationId, skills: string[], zones: string[],
  platformAccess: ('web'|'app')[], shift: 'MORNING'|'EVENING'|'NIGHT'|'FLEX',
  availability: 'ON_DUTY'|'OFF_DUTY'|'ON_LEAVE', status: 'ACTIVE'|'SUSPENDED',
  photoUrl, notificationPrefs: { push, email, whatsapp, quietHours: { from, to } },
  devices: [{ deviceId, platform, model, pushToken, lastSeenAt }],
  stats: { visitsMonth, onTimePct, avgRating },           // denormalised, refreshed nightly
  lastLoginAt, createdBy, createdAt, updatedAt, deletedAt
}

// designations · departments · zones · shifts (small master lists)
{ _id, title: { en, bn }, departmentId?, grade?, isActive, sortOrder }

// service_types
{
  _id, code, name: { en, bn }, requiredSkills: string[], defaultDurationMin, fee,
  checklist: [{ key, label: { en, bn }, mandatory: boolean, sortOrder }],
  vitalsRequired: string[],                                // e.g. ['bp','pulse','spo2']
  isActive
}

// patients
{
  _id, mrn?, name: { en, bn }, phone, altPhone, gender, dob?, ageYears?, bloodGroup?,
  address: { area, thana, district, full, landmark, geo?: { type:'Point', coordinates:[lng,lat] } },
  guardian: { name, relation, phone }, allergies: string[], conditions: string[],
  consent: { whatsapp: boolean, email: boolean, at, by }, tags: string[], notes,
  source, createdBy, createdAt, updatedAt, deletedAt
}

// homecare_requests   (one document = one home-care visit record)
{
  _id, requestNo: 'HC-260924-0007', patientId, patientSnapshot: { name, phone, address },
  requester: { type:'SELF'|'RELATIVE', name, relation, phone },
  services: [{ serviceTypeId, code, name }], priority: 'ROUTINE'|'URGENT'|'EMERGENCY',
  status: 'NEW'|'VERIFIED'|'CONFIRMED'|'ASSIGNED'|'ACCEPTED'|'EN_ROUTE'|'IN_PROGRESS'
        |'COMPLETED'|'CLOSED'|'RESCHEDULED'|'CANCELLED',
  preferred: { date, slot }, scheduledAt, expectedDurationMin,
  clinical: { complaint, notes, referringDoctor, allergies, attachmentIds: [] },
  assignment: {
    primaryStaffId, secondaryStaffIds: [], assignedBy, assignedAt, acceptedAt,
    respondBy, instructions, declines: [{ staffId, reason, at }]
  },
  timeline: {                                              // all Date, server-authoritative
    requestedAt, verifiedAt, confirmedAt, assignedAt, acceptedAt, enRouteAt,
    checkInAt, checkOutAt, completedAt, closedAt, rescheduledAt, cancelledAt
  },
  deviceStamps: [{ event, deviceAt, offline, deviceId }], // mobile-captured times
  visit: {
    checkIn: { at, geo?, accuracyM? }, checkOut: { at, geo? },
    checklist: [{ key, label, mandatory, done, doneAt, doneBy, note }],
    vitals: { bp, pulse, tempC, spo2, rbs, weightKg, painScore, recordedAt, abnormal: [] },
    medications: [{ drug, dose, route, time, by }], consumables: [{ item, qty }],
    notes: { clinical, nursing }, photoIds: [], signature: { type:'PAD'|'OTP'|'VERBAL', at, ref },
    durationMin, lateMin, overtimeMin, reportUrl
  },
  payment: { amount, method, status: 'PENDING'|'PAID'|'WAIVED', collectedBy, collectedAt },
  cancellation?: { reason, by, at }, reschedule?: [{ from, to, reason, by, at }],
  feedback?: { rating, comment, at },
  source, remarks, createdBy, version, createdAt, updatedAt, deletedAt
}

// assignment_logs   { requestId, fromStaffId, toStaffId, action:'ASSIGN'|'REASSIGN'|'ACCEPT'|'DECLINE'|'TIMEOUT', reason, by, at }
// attachments       { ownerType, ownerId, kind:'PRESCRIPTION'|'REPORT'|'WOUND_PHOTO'|'SIGNATURE'|'VISIT_REPORT', url, mime, size, uploadedBy, at }
// notifications     { userId, type, title, body, data:{ requestId, screen }, channels:['inapp','push'], status:{ inapp, push }, readAt, createdAt }
// message_logs      { channel:'EMAIL'|'WHATSAPP'|'SMS', provider:'gmail_smtp'|'gmail_api'|'wa_deeplink'|'wa_cloud', to, templateKey, lang, renderedText, requestId?, patientId?, initiatedBy, status:'PREPARED'|'QUEUED'|'SENT'|'SENT_CONFIRMED'|'DELIVERED'|'FAILED', providerId?, error?, at }
// audit_logs        { actorId, actorRole, action, entity, entityId, before, after, ip, userAgent, client:'web'|'app', serverAt }   // append-only
// sessions          { userId, deviceId, client, refreshTokenHash, expiresAt, revokedAt }
// settings          { key, value, updatedBy, updatedAt }   // non-secret config only
// counters          { key:'HC-260924', seq }               // request numbering
```

### 7.3 Indexes

| Collection | Index | Purpose |
|---|---|---|
| users | `{ phone:1 } unique`, `{ email:1 } unique sparse`, `{ employeeId:1 } unique`, `{ role:1, availability:1 }` | Login, assignment candidates |
| patients | `{ phone:1 }`, `{ mrn:1 } sparse`, text on `name.en, name.bn, phone`, `2dsphere address.geo` | Search, zone lookup |
| homecare_requests | `{ status:1, scheduledAt:1 }`, `{ 'assignment.primaryStaffId':1, status:1, scheduledAt:1 }`, `{ patientId:1, createdAt:-1 }`, `{ requestNo:1 } unique`, `{ priority:1, status:1 }` | Boards, staff visit list, patient history |
| notifications | `{ userId:1, readAt:1, createdAt:-1 }` | Notification centre + unread count |
| message_logs | `{ requestId:1, at:-1 }`, `{ status:1, at:1 }` | Record messages tab, outbox retry |
| audit_logs | `{ entity:1, entityId:1, serverAt:-1 }`, `{ actorId:1, serverAt:-1 }` | Audit viewer |

---

## 8. Caching Strategy (Redis / Upstash) — "read fast, write through"

| Key pattern | Contents | TTL | Invalidated on |
|---|---|---|---|
| `hc:dash:today` | Status counters, overdue count, awaiting-acceptance count | 30 s | Any request status change |
| `hc:board:{status}:{page}` | Patient / request board page payload | 60 s | Request create / update in that status |
| `hc:staff:visits:{userId}:{date}` | Staff's visit list for the day | 60 s | Assignment / status change for that staff |
| `hc:req:{id}` | Full request document | 5 min | Any write to that request (delete key) |
| `hc:candidates:{serviceCode}:{zone}:{date}` | Ranked assignment candidates | 60 s | Availability toggle, new assignment |
| `hc:master:service_types` · `hc:master:designations` · `hc:master:zones` | Master lists | 24 h | Admin edits master data |
| `hc:user:{id}:profile` | Role, platformAccess, status (for middleware) | 10 min | User update / suspend (also pushed to deny-list) |
| `hc:deny:{userId}` / `hc:deny:jti:{jti}` | Suspended users / revoked tokens | token lifetime | — |
| `hc:rl:login:{ip}` · `hc:rl:otp:{phone}` | Rate-limit counters (Upstash Ratelimit) | 15 min | — |
| `hc:notif:unread:{userId}` | Unread count for badges | 5 min | New notification / mark read |
| `hc:lock:assign:{requestId}` | Short mutex while two coordinators assign | 10 s | Auto |

Rules: cache-aside with `getOrSet(key, ttl, loader)`; writes update Mongo first, then delete affected keys (tag list per request stored in `hc:tags:req:{id}`); never cache patient clinical notes longer than 5 min; client side uses TanStack Query (`staleTime` 15–60 s) and the mobile app keeps an MMKV cache for the visit list and visit detail for offline use.

---

## 9. API Design (`/api/v1`, JSON, bearer or cookie auth)

| Area | Endpoint | Roles |
|---|---|---|
| Auth | `POST /auth/login {identifier,password,client}` · `POST /auth/refresh` · `POST /auth/logout` · `POST /auth/otp/request` · `POST /auth/otp/verify` · `POST /auth/devices/push-token` · `GET /auth/me` | all |
| Users | `GET /users?role&dept&availability&q` · `POST /users` · `GET/PATCH /users/:id` · `PATCH /users/:id/status` · `POST /users/import` · `PATCH /users/me/availability` | SUPER_ADMIN (write), HC_ADMIN (read), self (availability) |
| Master | `GET/POST/PATCH /designations` · `/departments` · `/zones` · `/service-types` · `/shifts` | SUPER_ADMIN write, all read |
| Patients | `GET /patients?q&zone&status` · `POST /patients` · `GET/PATCH /patients/:id` · `GET /patients/:id/visits` · `GET /patients/board?status&date&staff` | admin roles; field read of assigned |
| Requests | `GET /requests?status&date&staff&priority&q&cursor` · `POST /requests` · `GET/PATCH /requests/:id` | admin roles |
| Lifecycle | `POST /requests/:id/verify` · `/confirm` · `/assign {primaryStaffId,secondaryStaffIds,scheduledAt,instructions}` · `/reassign` · `/reschedule` · `/cancel` · `/close` | HC_ADMIN, SUPER_ADMIN |
| Staff actions | `POST /requests/:id/accept` · `/decline {reason}` · `/en-route` · `/check-in {geo?,deviceAt}` · `PATCH /requests/:id/checklist/:key {done,note,deviceAt}` · `PUT /requests/:id/vitals` · `PUT /requests/:id/notes` · `POST /requests/:id/medications` · `POST /requests/:id/attachments` · `POST /requests/:id/signature` · `POST /requests/:id/check-out` · `POST /requests/:id/complete` | assigned staff only |
| My visits | `GET /me/visits?date&status` · `GET /me/visits/today` | field roles |
| Assignment help | `GET /requests/:id/candidates` (ranked list with badges) · `GET /assignment-logs?requestId` | HC_ADMIN |
| Notifications | `GET /notifications?cursor` · `PATCH /notifications/:id/read` · `POST /notifications/read-all` · `GET /notifications/unread-count` · `PATCH /me/notification-prefs` | self |
| Messages | `POST /messages/email/send {requestId,templateKey,to,lang}` · `POST /messages/whatsapp/prepare {requestId,templateKey,to,lang}` · `PATCH /messages/:id {status}` · `GET /messages?channel&requestId&status` · `POST /messages/whatsapp/webhook` (Cloud API, Phase 3) | per §3.3 |
| Reports | `GET /reports/summary?from&to` · `/reports/staff` · `/reports/sla` · `/reports/services` · `GET /reports/export?type=csv|xlsx` | HC_ADMIN, VIEWER, SUPER_ADMIN |
| Settings | `GET/PATCH /settings` · `POST /settings/email/test` · `GET/PUT /templates/:key` | SUPER_ADMIN (HC_ADMIN templates) |
| Audit | `GET /audit?entity&entityId&actor&from&to&cursor` | SUPER_ADMIN, HC_ADMIN |
| Jobs (QStash-signed) | `POST /jobs/reminders` · `/jobs/escalations` · `/jobs/outbox` · `/jobs/digest` · `/jobs/stats-refresh` | system |

Conventions: cursor pagination `{items, nextCursor}`; errors `{error:{code,message,fields?}}`; every mutating call requires `Idempotency-Key`; state transitions validated server-side against §4.1 (invalid transition → `409 INVALID_TRANSITION`); all mutations write `audit_logs` in the same operation.

---

## 10. Message Templates (Bangla + English)

Placeholders: `{patientName} {requestNo} {serviceType} {date} {slot} {staffName} {designation} {address} {patientPhone} {age} {gender} {notes} {feedbackLink} {hospitalPhone}`

| Key | Channel | Bangla (default for patients) | English |
|---|---|---|---|
| `patient_confirmed` | WhatsApp / Email | প্রিয় {patientName}, আপনার হোম কেয়ার অনুরোধ (নং {requestNo}) নিশ্চিত হয়েছে। সেবা: {serviceType}। সময়: {date}, {slot}। আমাদের টিম নির্ধারিত সময়ে পৌঁছাবে। প্রয়োজনে কল করুন: {hospitalPhone} — ইউনিকো হসপিটালস, ফ্যামিলি মেডিসিন | Dear {patientName}, your home care request ({requestNo}) is confirmed. Service: {serviceType}. Time: {date}, {slot}. Our team will arrive at the scheduled time. Need help? Call {hospitalPhone}. — Unico Hospitals, Family Medicine |
| `patient_assigned` | WhatsApp | {patientName}, আপনার সেবার জন্য {staffName} ({designation}) নিযুক্ত হয়েছেন। সময়: {date}, {slot}। | {patientName}, {staffName} ({designation}) has been assigned to your visit. Time: {date}, {slot}. |
| `staff_assigned` | WhatsApp / Push / Email | হোম কেয়ার অ্যাসাইনমেন্ট — {requestNo}<br>রোগী: {patientName} ({age}/{gender})<br>সেবা: {serviceType}<br>ঠিকানা: {address}<br>সময়: {date}, {slot}<br>ফোন: {patientPhone}<br>নোট: {notes}<br>অ্যাপে Accept করুন। | Home care assignment — {requestNo}<br>Patient: {patientName} ({age}/{gender})<br>Service: {serviceType}<br>Address: {address}<br>Time: {date}, {slot}<br>Phone: {patientPhone}<br>Notes: {notes}<br>Please Accept in the app. |
| `patient_en_route` | WhatsApp | {staffName} ({designation}) আপনার বাসার উদ্দেশ্যে রওনা হয়েছেন। | {staffName} ({designation}) is on the way to your home. |
| `patient_arrived` | WhatsApp | {staffName} ({designation}) আপনার বাসায় পৌঁছেছেন। — ইউনিকো হসপিটালস | {staffName} ({designation}) has arrived at your home. — Unico Hospitals |
| `patient_completed` | WhatsApp / Email | আপনার হোম কেয়ার সেবা সম্পন্ন হয়েছে। ধন্যবাদ। আপনার মতামত দিন: {feedbackLink} | Your home care visit is complete. Thank you. Share your feedback: {feedbackLink} |
| `patient_rescheduled` | WhatsApp | আপনার হোম কেয়ার ভিজিট নতুন সময়ে নির্ধারিত হয়েছে: {date}, {slot}। | Your home care visit has been rescheduled to {date}, {slot}. |
| `patient_cancelled` | WhatsApp | আপনার হোম কেয়ার অনুরোধ (নং {requestNo}) বাতিল হয়েছে। প্রয়োজনে কল করুন: {hospitalPhone} | Your home care request ({requestNo}) has been cancelled. Call {hospitalPhone} if you need help. |
| `dept_visit_report` | Email | — | Visit report {requestNo} · {patientName} · {serviceType} · {staffName} · Check-in {checkInAt} · Check-out {checkOutAt} · Duration {durationMin} min · Checklist {doneCount}/{totalCount} · Vitals summary · Notes · Attachments (PDF attached) |
| `admin_daily_digest` | Email | — | Today: {newCount} new · {completedCount} completed · {overdueCount} overdue · avg response {avgResponse} min · on-time {onTimePct}% · staff table |
| `admin_escalation` | Push / Email | — | {requestNo} still unaccepted after {minutes} min ({staffName} declined: {reason}). Next candidate: {nextStaff}. |

UI glossary (EN → BN) for labels: Home Care → হোম কেয়ার · Request → অনুরোধ · Patient → রোগী · Visit → ভিজিট · Assign → অ্যাসাইন · Accept → গ্রহণ · Decline → প্রত্যাখ্যান · Check-in → চেক-ইন · Check-out → চেক-আউট · Complete → সম্পন্ন · Completed → সম্পন্ন হয়েছে · Pending → অপেক্ষমাণ · Cancelled → বাতিল · Urgent → জরুরি · Emergency → ইমার্জেন্সি · Address → ঠিকানা · Schedule → সময়সূচি · Notifications → নোটিফিকেশন · Staff → স্টাফ · Designation → পদবি · Report → রিপোর্ট.

---

## 11. Security, Privacy & Compliance

| Area | Control |
|---|---|
| Passwords & tokens | Argon2id hashing; access JWT 15 min, refresh 30 days rotating, revocation via Redis deny-list; `aud` + `role` claims |
| Authorisation | RBAC middleware on every handler; field staff can read only requests where they are assigned; server-side ownership checks, never client-only |
| Input | Zod validation on all bodies / params; file type + size limits; image EXIF stripped except timestamp watermark |
| Transport | HTTPS only; HSTS; CORS restricted to the web origin and app scheme; secure / httpOnly / sameSite cookies |
| Patient data (PHI) | Data minimisation in WhatsApp messages (no diagnosis, no lab values); consent flag before patient-facing messages; phone numbers masked for VIEWER; clinical notes excluded from list endpoints |
| Secrets | Only in Vercel env vars (Gmail, WhatsApp, JWT, Mongo, Upstash); never stored in MongoDB; Settings UI shows masked values only |
| Audit | Append-only `audit_logs`; login history; export events logged; admin cannot delete audit rows |
| Rate limiting | Login, OTP, message sending (per user per minute), public web form |
| Retention & deletion | Soft delete; 7-year retention for visit + audit; patient data-erasure request handled by SUPER_ADMIN with audit entry |
| Device security (app) | Secure storage for tokens, biometric unlock optional, auto-lock after 10 min, remote sign-out |
| Backups | Atlas continuous backup (M10) or daily `mongodump` to R2 on M0 |

---

## 12. Environment & Deployment

### 12.1 Environment variables (Vercel → Project → Settings → Environment Variables)

```
MONGODB_URI=
REDIS_URL= / UPSTASH_REDIS_REST_URL= / UPSTASH_REDIS_REST_TOKEN=
QSTASH_TOKEN= / QSTASH_CURRENT_SIGNING_KEY= / QSTASH_NEXT_SIGNING_KEY=
JWT_ACCESS_SECRET= / JWT_REFRESH_SECRET=
APP_BASE_URL=https://<unico-app>.vercel.app
# Email — choose A or B
GMAIL_MODE=smtp|api
GMAIL_USER=homecare@unicohospitals.com
GMAIL_APP_PASSWORD=                       # mode A
GMAIL_CLIENT_ID= / GMAIL_CLIENT_SECRET= / GMAIL_REFRESH_TOKEN=   # mode B
EMAIL_FROM_NAME="Unico Hospitals · Home Care"
# WhatsApp
WA_DEEPLINK_DEFAULT_COUNTRY=880
WA_CLOUD_TOKEN= / WA_PHONE_NUMBER_ID= / WA_WEBHOOK_VERIFY_TOKEN= / WA_APP_SECRET=   # Phase 3
# Push & files
EXPO_ACCESS_TOKEN=
BLOB_READ_WRITE_TOKEN=   (or R2_ACCOUNT_ID / R2_ACCESS_KEY_ID / R2_SECRET_ACCESS_KEY / R2_BUCKET)
# Toggles
FEATURE_AUTO_ASSIGN=false
FEATURE_GPS_REQUIRED_CHECKIN=false
FEATURE_OTP_CONFIRMATION=true
```

### 12.2 Deployment checklist

| Step | Action |
|---|---|
| 1 | MongoDB Atlas cluster (region Singapore / Mumbai for Dhaka latency), create indexes from §7.3, seed roles, departments, designations, service types, one SUPER_ADMIN |
| 2 | Upstash Redis + QStash in the same region; add schedules: reminders `*/5 * * * *`, escalations `*/5 * * * *`, outbox `*/2 * * * *`, digest `0 20 * * *` (Asia/Dhaka), stats-refresh `0 2 * * *` |
| 3 | Gmail: enable 2-Step Verification → App Password (mode A) **or** Google Cloud OAuth client + refresh token (mode B); send test email from Settings |
| 4 | Vercel: env vars, Pro plan for commercial use, `after()` enabled (Next.js 15), protected `(admin)` route group |
| 5 | Expo: EAS project, `expo-notifications` + FCM credentials (Android) / APNs key (iOS), EAS Build → internal APK for pilot, later Play Store (internal testing track) |
| 6 | Pilot with 1 coordinator + 5 field staff for 2 weeks; review audit + message logs; tune SLA thresholds |
| 7 | Phase 3: Meta Business verification for Unico Hospitals → WhatsApp Cloud API number → template approval → webhook |

---

## 13. UI Design System (for Claude Design)

### 13.1 Design principles
1. **Field-first.** Nurses use the app one-handed, walking, sometimes with gloves: large tap targets (≥ 48 px), one primary action per screen, bottom-anchored buttons.
2. **Status is always visible.** Colour-coded status chip + timeline stepper on every request / visit view.
3. **Time is a first-class element.** Scheduled vs actual, countdowns, elapsed timers and stamped ticks are shown inline, never hidden in a details page.
4. **Bilingual.** Every label has EN + BN; Bangla uses Noto Sans Bengali (correct যুক্তাক্ষর rendering); language toggle in header / profile.
5. **Calm clinical look.** White surfaces, teal primary, generous whitespace, soft shadows; red only for emergency / danger; dark mode for night shifts.
6. **Never lose work.** Offline banner, pending-sync count, autosave on every field.

### 13.2 Colour tokens (replace primary with the official Unico brand hex if available)

| Token | Hex | Use |
|---|---|---|
| `primary` | `#0E7C86` | Buttons, active tab, links, brand accents |
| `primary-700` | `#0B5F66` | Pressed / hover |
| `primary-50` | `#E6F4F5` | Selected rows, soft backgrounds |
| `secondary` (navy) | `#1F3864` | Web sidebar, headings on web, report headers |
| `accent` (amber) | `#F59E0B` | Urgent priority, in-progress, warnings |
| `danger` | `#DC2626` | Emergency, cancel, destructive, overdue |
| `success` | `#16A34A` | Completed, on-time, ticks |
| `info` | `#2563EB` | Verified, informational |
| `warning` | `#F97316` | Rescheduled, late |
| `neutral-900 / 700 / 500 / 300 / 100 / 0` | `#0F172A` `#334155` `#64748B` `#CBD5E1` `#F1F5F9` `#FFFFFF` | Text, borders, backgrounds |
| `dark-bg / dark-surface` | `#0B1220` `#111A2E` | Dark mode |

**Status chips**

| Status | Chip colour | Status | Chip colour |
|---|---|---|---|
| NEW | neutral-500 on neutral-100 | IN_PROGRESS | accent `#F59E0B` (with pulsing dot) |
| VERIFIED | info `#2563EB` | COMPLETED | success `#16A34A` |
| CONFIRMED | indigo `#4F46E5` | CLOSED | emerald-800 `#065F46` |
| ASSIGNED | violet `#7C3AED` | RESCHEDULED | warning `#F97316` |
| ACCEPTED | primary `#0E7C86` | CANCELLED | danger `#DC2626` |
| EN_ROUTE | cyan `#0891B2` | — | — |

**Priority badges:** ROUTINE = neutral outline · URGENT = amber filled · EMERGENCY = red filled with subtle pulse.

### 13.3 Typography, spacing, shape

| Element | Spec |
|---|---|
| Fonts | Inter (EN) · Noto Sans Bengali (BN, +1 px size, line-height 1.6) · tabular numerals for times |
| Scale | Display 28/34 · H1 24/30 · H2 20/28 · H3 17/24 · Body 15/22 · Caption 13/18 · Micro 11/16 |
| Grid | 4-pt spacing; page padding 16 (mobile) / 24–32 (web) |
| Radius | Inputs 8 · Cards 12 · Sheets / modals 16 · Chips full |
| Elevation | Card `0 1px 3px rgba(15,23,42,.08)` · Sheet `0 -8px 24px rgba(15,23,42,.12)` |
| Icons | Lucide, 20 px inline / 24 px tab bar |
| Frames | Mobile 390 × 844 (safe areas) · Web 1440 × 900 (sidebar 264 px, collapses to 72 px) |

### 13.4 Component library (specify once, reuse everywhere)

| Component | Spec |
|---|---|
| **StatusChip** | Dot + label, colours from §13.2; sizes sm / md |
| **PriorityBadge** | Outline / filled per priority |
| **SLAPill** | Countdown "Confirm in 04:12" (green → amber → red), turns to "Overdue 12 min" |
| **TimelineStepper** | Vertical (mobile) / horizontal (web); each step shows label + stamped time; current step highlighted; late / overtime annotated |
| **PatientCard** | Avatar initials, name EN/BN, age · gender, MRN, phone, address line, allergies badge |
| **ContactBar** | Three equal buttons: Call · WhatsApp (opens prefilled message) · Map |
| **VisitCard** (list) | Time, service, patient, address short, StatusChip, PriorityBadge, staff avatar, SLAPill |
| **CandidateCard** (assign) | Photo, name, designation, badges (Skill ✓ · Zone ✓ · Free 15–17 · 2 visits today · On leave), score bar, **Assign** button |
| **ChecklistItem** | Large checkbox, label, mandatory star, stamped time "14:32", optional note field; untick opens reason sheet |
| **TimerWidget** | Big elapsed mm:ss, scheduled vs actual, late / overtime tag |
| **VitalsGrid** | 2-column numeric inputs with units and normal-range hints; abnormal → red border + flag icon |
| **SignaturePad / OTPBox** | Full-width pad with clear; or 4-digit OTP |
| **SyncBanner** | Top strip: "Offline · 3 actions pending" / "Syncing…" |
| **NotificationItem** | Icon by type, title, body, relative time, unread dot, deep link |
| **KanbanCard** (web) | Request no, patient, service, slot, staff avatar, PriorityBadge, SLAPill; drag handle |
| **DataTable** (web) | Sticky header, column filters, row actions, bulk select, export |
| **Empty / Loading / Error** | Illustrated empty state with one CTA; skeleton loaders; inline retry |
| **LanguageToggle** | EN · বাং segmented control |

---

## 14. Screen Inventory & Specs

### 14.1 Navigation map

**Mobile app (all roles)** — bottom tabs: **Home · Visits · Notifications · Profile**. Admin roles additionally get an **Admin** tab (Requests · Patient board · Assign · New request) and a floating **+ New request** button on Home.

**Web admin** — left sidebar: Dashboard · Requests · Patients · Staff · Reports · Messages · Notifications · Settings (Users & designations · Service types · Templates · Integrations · Audit log). Top bar: global search (phone / MRN / request no), quick **+ New request**, bell with unread badge, language toggle, user menu.

### 14.2 Mobile app screens (390 × 844)

| ID · Screen | Purpose & key elements | Primary actions | States |
|---|---|---|---|
| **M01 Login** | Unico logo, "Unico HomeCare", employee ID / phone + password, remember device, language toggle | Sign in · Forgot password | Error "app-only account" (for web mismatch shown on web), loading |
| **M02 OTP / Reset** | 4-digit OTP boxes, resend timer | Verify · Resend | Invalid, expired |
| **M03 Home (Today)** | Greeting + designation, availability toggle (On duty / Off / Leave), KPI chips (Today 4 · Awaiting accept 1 · Completed 2), **Next visit** hero card with countdown + ContactBar, today's VisitCards, SyncBanner | Open visit · Accept pending · + New request (admin) | Empty "No visits today", offline |
| **M04 Visits** | Segmented Today / Upcoming / Completed, search, filter (service, status), grouped by date | Open visit | Empty, loading skeleton |
| **M05 Visit detail** | StatusChip + PriorityBadge, TimelineStepper with stamped times, PatientCard, ContactBar, schedule block (scheduled · expected duration · TimerWidget once started), instructions, attachments (prescription thumbnails), checklist progress "3/6", bottom action bar (next step only) | Start journey · Check-in · Checklist · Check-out · Complete · Send WhatsApp | Awaiting acceptance (sheet M06), late flag, overtime, offline pending |
| **M06 Accept / Decline sheet** | "Respond in 12:40" countdown, summary (patient, service, time, address, distance), decline reasons radio + note | Accept · Decline | Timed out |
| **M07 Check-in** | Confirm arrival card, time stamp preview, optional mini-map with GPS accuracy, late warning if > +10 min | Confirm check-in | GPS unavailable fallback |
| **M08 Checklist** | Progress bar, sections Mandatory / Optional, ChecklistItems with stamped times, add ad-hoc item, notes per item | Tick · Add item · Continue | Untick reason sheet, all-mandatory-done banner |
| **M09 Vitals** | VitalsGrid (BP, pulse, temp, SpO₂, RBS, weight, pain), recorded time | Save vitals · Flag coordinator | Abnormal highlight |
| **M10 Notes & medications** | Clinical / nursing notes (voice-to-text optional), medications list rows (drug, dose, route, time), consumables | Save | Autosaved indicator |
| **M11 Photos** | Camera / gallery grid, kind selector (wound, dressing, sample label), time watermark | Add photo · Remove | Upload progress, retry |
| **M12 Patient confirmation** | Tabs Signature / OTP / Verbal; SignaturePad; relation selector | Confirm | OTP resend |
| **M13 Check-out & completion** | Summary: check-in / check-out times, duration, checklist 6/6, vitals snapshot, photos count, payment collected toggle + amount, final remarks | Check-out → Complete visit | Blocked if mandatory items missing (list shown) |
| **M14 Notifications** | Today / Earlier groups, NotificationItems, mark all read | Open target · Mark read | Empty |
| **M15 Profile & settings** | Photo, name, designation, department, employee ID, stats (visits this month, on-time %), availability, notification preferences, language, dark mode, devices, sign out | Edit prefs · Sign out | — |
| **M16 Patient board (admin)** | Search by phone / MRN / name, filter chips (status, zone, priority), rows with StatusChip, next visit, staff | Open record · Call · WhatsApp · Assign | Empty |
| **M17 Request inbox (admin)** | NEW / CONFIRMED lists with SLAPill, quick actions | Verify · Confirm · Assign · Cancel | — |
| **M18 Assign (admin)** | Request summary, date/time picker, CandidateCards ranked with badges, secondary staff selector, instructions field | Assign · Reassign | No candidates → suggest change slot |
| **M19 New request (admin / front desk)** | 3-step form: Patient (search or new) → Service & schedule → Clinical & payment; attachments | Save · Save & confirm | Duplicate warning |
| **M20 Day route** | Ordered list / map of the day's visits with travel gaps | Open visit · Navigate | — |

### 14.3 Web admin screens (1440 × 900)

| ID · Screen | Purpose & key elements | Primary actions | States |
|---|---|---|---|
| **W01 Login** | Same as M01; shows "This account is app-only" for field users | Sign in | — |
| **W02 Dashboard** | KPI tiles (New, Confirmed, Assigned, In progress, Completed, Overdue, Awaiting accept), 14-day requests chart, service mix, on-time %, escalation list, live "in progress now" panel with TimerWidgets | Open request · Assign | Skeletons |
| **W03 Requests board** | Kanban ↔ Table toggle, filters (status, priority, service, staff, zone, date), KanbanCards with SLAPill, drag between allowed columns | + New request · Open · Assign · Bulk export | Empty column, permission-denied drag toast |
| **W04 Request detail** | Header (request no, StatusChip, PriorityBadge, SLAPill, actions), tabs: Overview · Timeline (TimelineStepper + all timing metrics) · Assignment (history) · Visit data (checklist ticks with times, vitals, notes, medications, photos, signature, report PDF) · Messages (email / WhatsApp / push logs, resend) · Attachments · Audit | Verify · Confirm · Assign · Reschedule · Cancel · Close · Send email · Send WhatsApp | Version conflict prompt |
| **W05 New / edit request** | 3-step form as M19 with patient search drawer, map pin, fee calculator | Save · Save & confirm · Save & assign | Duplicate warning |
| **W06 Assign drawer** | CandidateCards ranked (score bar + badges), availability calendar strip, schedule, expected duration, instructions, secondary staff, fee | Assign · Notify via WhatsApp toggle | No candidates |
| **W07 Patient board** | DataTable: patient, phone, latest status, next visit, staff, priority, zone; quick actions Call / WhatsApp / Open / Assign | + New patient · Export | Empty |
| **W08 Patient profile** | Demographics + guardian + consent, address history, visit timeline (all requests with status & times), documents, notes, outstanding balance | Edit · New request for this patient | — |
| **W09 Staff & users** | DataTable (name, designation, department, role, platform access, availability, status, last login); Add / Edit drawer with all §3.2 fields; bulk import | Add user · Edit · Suspend · Reset password · Force sign-out | Validation errors |
| **W10 Designations & departments** | Two master lists with EN / BN titles, grade, active toggle, reorder | Add · Edit · Deactivate | In-use warning |
| **W11 Service types & checklists** | Service list; editor for checklist items (mandatory flag, EN / BN), default duration, required skills, fee, vitals required | Add · Edit · Duplicate | — |
| **W12 Messages log** | Tabs Email / WhatsApp / Push; table with recipient, template, status, time, initiated by; preview; resend | Resend · Export | Failed filter |
| **W13 Notifications centre** | Same as M14 with filters | Mark read | — |
| **W14 Reports** | Date range, group by (day / staff / service / zone), charts + tables for volume, response / assignment / acceptance / duration metrics, on-time %, declines; export CSV / XLSX / PDF | Export | — |
| **W15 Settings & integrations** | Cards: General (hospital info, phone, slots, working hours, zones, shifts) · SLA thresholds · Gmail (mode, masked creds, **Send test**) · WhatsApp (deep link country code, Cloud API status) · Push (Expo status) · Feature toggles · Templates editor (EN / BN with placeholders, preview) | Save · Test | Test result toast |
| **W16 Audit log** | Filters (entity, user, action, date), rows with before / after diff viewer | Export | — |

---

## 15. Claude Design Prompt (copy-paste)

```
You are designing the UI for "Unico HomeCare" — the Home Care Module of the Family Medicine
department at Unico Hospitals PLC, Dhaka. It is an internal staff system with two surfaces:

1) A mobile app (390x844, iOS + Android) used by field staff (doctors, nurses, physiotherapists,
   lab technicians) and by coordinators. Field staff are app-only.
2) A web admin (1440x900, left sidebar 264px) used by coordinators and administrators.

Users: Home Care Coordinator (web + app), Front desk (web + app), Doctor / Nurse / Allied staff (app only),
Super admin (web + app), Management viewer (web, read-only).

Core workflow (status chips, in order): NEW -> VERIFIED -> CONFIRMED -> ASSIGNED -> ACCEPTED -> EN_ROUTE ->
IN_PROGRESS -> COMPLETED -> CLOSED, plus RESCHEDULED and CANCELLED. Every transition has a stamped time.
Field staff: Start journey -> Check-in -> Checklist (each tick shows its time) -> Vitals -> Notes/Photos ->
Patient signature or OTP -> Check-out -> Complete (only when all mandatory items are ticked).
Coordinators: create/verify/confirm requests, assign staff from a ranked candidate list (badges: Skill ok,
Zone ok, Free 15-17, 2 visits today), monitor a live board, close visits, send email (Gmail) and WhatsApp
(prefilled message that opens WhatsApp) from any record.

Design system:
- Colours: primary teal #0E7C86 (700 #0B5F66, 50 #E6F4F5), secondary navy #1F3864, amber #F59E0B (urgent,
  in progress), red #DC2626 (emergency, cancel, overdue), green #16A34A (completed, on time),
  blue #2563EB (verified), orange #F97316 (rescheduled). Neutrals slate 900/700/500/300/100/white.
  Status chip colours: NEW slate, VERIFIED blue, CONFIRMED indigo #4F46E5, ASSIGNED violet #7C3AED,
  ACCEPTED teal, EN_ROUTE cyan #0891B2, IN_PROGRESS amber with pulsing dot, COMPLETED green,
  CLOSED emerald #065F46, RESCHEDULED orange, CANCELLED red.
- Type: Inter for English, Noto Sans Bengali for Bangla (line-height 1.6), tabular numerals for times.
  Scale 28/24/20/17/15/13/11. 4pt grid. Radius 8 inputs, 12 cards, 16 sheets, full chips.
  Lucide icons. Soft shadows. Light and dark mode.
- Principles: field-first (48px tap targets, one primary bottom-anchored action per screen), status always
  visible, time is first-class (countdowns, elapsed timers, stamped ticks inline), bilingual EN/BN toggle,
  calm clinical look, offline banner with pending-sync count.

Components to define once: StatusChip, PriorityBadge, SLAPill (countdown green->amber->red), TimelineStepper
with stamped times, PatientCard, ContactBar (Call / WhatsApp / Map), VisitCard, CandidateCard, ChecklistItem
(big checkbox + stamped time + note), TimerWidget, VitalsGrid, SignaturePad/OTPBox, SyncBanner,
NotificationItem, KanbanCard, DataTable, Empty/Loading/Error states, LanguageToggle.

Deliver these screens with realistic Bangladeshi sample data (names, Dhaka areas, +880 numbers):
Mobile: Login; Home (Today) with availability toggle, next-visit hero card and countdown; Visits list;
Visit detail with timeline stepper and bottom action bar; Accept/Decline sheet with countdown; Check-in;
Checklist with stamped ticks; Vitals; Notes & medications; Photos; Patient confirmation (signature/OTP);
Check-out & completion summary; Notifications; Profile; Admin: Patient board, Request inbox, Assign with
ranked candidates, New request 3-step form, Day route.
Web: Login; Dashboard; Requests board (Kanban + table); Request detail with tabs (Overview, Timeline,
Assignment, Visit data, Messages, Attachments, Audit); New request form; Assign drawer; Patient board;
Patient profile; Staff & users with Add-user drawer (designation, role, web/app access, skills, zones);
Designations & departments; Service types & checklist editor; Messages log (Email/WhatsApp/Push);
Reports; Settings & integrations (Gmail test send, WhatsApp, templates editor EN/BN); Audit log.

Show light mode for web and both light and dark for the mobile Visit detail and Checklist screens.
Keep patient data minimal on any WhatsApp preview. Label every screen with its ID from the spec
(M01..M20, W01..W16).
```

---

## 16. Delivery Roadmap

| Phase | Weeks | Deliverables | Exit criteria |
|---|---|---|---|
| **0 · Foundation** | 1 | Repo layout, Atlas + Upstash, auth (web cookie + app bearer), RBAC middleware, platform-access rule, users / designations / departments CRUD, audit logger, seed data | Admin can log in on web, nurse can log in on app only |
| **1 · Intake & board** | 2–3 | Patient registry, request form (3-step), request numbering, patient board, live Kanban, in-app + push notifications, notification centre | Coordinator creates and confirms a request; nurse receives push |
| **2 · Assignment & visit** | 4–5 | Candidate ranking, assign / accept / decline / timeout / reassign, visit detail, check-in, checklist ticks with times, vitals, notes, photos, signature / OTP, check-out, completion, timing metrics, offline queue | End-to-end visit completed from the app with full timeline |
| **3 · Messaging** | 6 | Gmail email (mode A or B), templates EN / BN, WhatsApp deep link with logging, daily digest, escalations via QStash, message log screen, visit report PDF | Patient receives confirmation + completion messages; department receives report email |
| **4 · Reports & polish** | 7 | Dashboard charts, staff / SLA / service reports, exports, settings UI, service-type editor, dark mode, pilot fixes | 2-week pilot with 1 coordinator + 5 staff signed off |
| **5 · Automation** | 8+ | WhatsApp Cloud API (auto-send + inbound), auto-assign toggle, shift roster, GPS route, patient feedback link, SMS gateway, optional patient portal | Zero manual messaging for standard flows |

---

## 17. Assumptions & Open Questions

| # | Assumption made in this plan | Confirm / change |
|---|---|---|
| 1 | The existing Unico Vercel app is Next.js and the module is added as a protected `(admin)/homecare` route group + `/api/v1` | If it is a pure static site, the API still lives in Next.js route handlers on Vercel |
| 2 | Mobile app is Expo (React Native) for Android + iOS | Switch to Kotlin + Jetpack Compose if Android-only is acceptable |
| 3 | Sending email address is a Gmail / Google Workspace account owned by the department | Mode A (App Password) for free Gmail, Mode B (OAuth2) for Workspace |
| 4 | WhatsApp v1 = deep link from the staff phone; automated sends come in Phase 5 after Meta Business verification for Unico Hospitals | Need the hospital's Meta Business Manager + a dedicated number |
| 5 | Brand colours: teal / navy placeholders | Provide official Unico Hospitals hex codes and logo |
| 6 | Bangla is the default language for patient messages; English for staff UI with BN toggle | Confirm |
| 7 | Payment is recorded only (amount, method, status), no gateway | Add bKash / SSLCommerz later if needed |
| 8 | MRN comes from the hospital HIS but is entered manually in v1 | HIS API integration later |
| 9 | Vercel Pro plan (commercial use) | Or self-host the same app on a Coolify VPS |
| 10 | Pilot scope: Family Medicine home care only; other departments later as separate service types | Confirm |

---

*End of document — Unico Family Medicine · Home Care Module Plan v1.0*
